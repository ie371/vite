const opt = [
  { text: "нет", value: 0 },
  { text: "15", value: 15 },
  { text: "20", value: 20 },
  { text: "25", value: 25 },
  { text: "32", value: 32 },
  { text: "40", value: 40 },
  { text: "50", value: 50 },
  { text: "65", value: 65 },
  { text: "80", value: 80 },
  { text: "100", value: 100 },
  { text: "125", value: 125 },
  { text: "150", value: 150 },
  { text: "200", value: 200 },
  { text: "250", value: 250 },
  { text: "300", value: 300 },
  { text: "350", value: 350 },
  { text: "400", value: 400 },
  { text: "500", value: 500 },
];

export default opt;
